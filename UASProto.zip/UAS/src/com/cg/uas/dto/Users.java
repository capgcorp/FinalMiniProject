package com.cg.uas.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Users")
public class Users

{

	@Id
	@Column(name = "login_Id", length = 5)
	private String login_Id;

	@Column(name = "password", length = 10)
	private String password;

	@Column(name = "role", length = 5)
	private String role;

	public Users() {

	}

	public Users(String login_id, String password, String role) {
		super();
		this.login_Id = login_id;
		this.password = password;
		this.role = role;
	}

	public String getLogin_id() {
		return login_Id;
	}

	public void setLogin_id(String login_id) {
		this.login_Id = login_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "Users [login_id=" + login_Id + ", password=" + password
				+ ", role=" + role + "]";
	}

}
