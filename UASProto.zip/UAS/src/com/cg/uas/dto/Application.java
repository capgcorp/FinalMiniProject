package com.cg.uas.dto;



import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Application")
public class Application

{


	@Id
	@SequenceGenerator(name="seq",sequenceName="Application_id", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	@Column(name="application_Id")
	private int application_Id;
	
	@Column(name="full_Name",length=20)
	private String full_Name;
	
	@Column(name="date_Of_Birth")
	private Date date_Of_Birth;
	
	@Column(name="highest_Qualification",length=10)
	private String highest_Qualification;
	
	@Column(name="marks_Obtained")
	private int marks_Obtained;
	
	@Column(name="goals",length=20)
	private String goals;
	
	@Column(name="email_Id",length=20)
	private String email_Id;
	
	
	@Column(name="scheduled_Program_Id",length=5)
	private String scheduled_Program_Id;
	
	
	@Column(name="status",length=10)
	private String status;
	
	@Column(name="date_Of_Interview")
	private Date date_Of_Interview;
	
	
	@Column(name="address",length=30)
	private String address;

	@Override
	public String toString() {
		return "Application [application_Id=" + application_Id + ", full_Name="
				+ full_Name + ", date_Of_Birth=" + date_Of_Birth
				+ ", highest_Qualification=" + highest_Qualification
				+ ", marks_Obtained=" + marks_Obtained + ", goals=" + goals
				+ ", email_Id=" + email_Id + ", scheduled_Program_Id="
				+ scheduled_Program_Id + ", status=" + status
				+ ", date_Of_Interview=" + date_Of_Interview + ", address="
				+ address + "]";
	}

	public String toString2() {
		return application_Id + "," + full_Name + "," + date_Of_Birth + ","
				+ highest_Qualification + "," + marks_Obtained + "," + goals
				+ "," + email_Id + "," + scheduled_Program_Id + "," + status
				+ "," + date_Of_Interview + "," + address+"\n";
	}

	public int getApplication_Id() {
		return application_Id;
	}

	public void setApplication_Id(int application_Id) {
		this.application_Id = application_Id;
	}

	public String getFull_Name() {
		return full_Name;
	}

	public void setFull_Name(String full_Name) {
		this.full_Name = full_Name;
	}

	public Date getDate_Of_Birth() {
		return date_Of_Birth;
	}

	public void setDate_Of_Birth(Date dob) {
		this.date_Of_Birth = dob;
	}

	public String getHighest_Qualification() {
		return highest_Qualification;
	}

	public void setHighest_Qualification(String highest_Qualification) {
		this.highest_Qualification = highest_Qualification;
	}

	public int getMarks_Obtained() {
		return marks_Obtained;
	}

	public void setMarks_Obtained(int marks_Obtained) {
		this.marks_Obtained = marks_Obtained;
	}

	public String getGoals() {
		return goals;
	}

	public void setGoals(String goals) {
		this.goals = goals;
	}

	public String getEmail_Id() {
		return email_Id;
	}

	public void setEmail_Id(String email_Id) {
		this.email_Id = email_Id;
	}

	public String getScheduled_Program_Id() {
		return scheduled_Program_Id;
	}

	public void setScheduled_Program_Id(String string) {
		this.scheduled_Program_Id = string;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getDate_Of_Interview() {
		return date_Of_Interview;
	}

	public void setDate_Of_Interview(Date date_Of_Interview) {
		this.date_Of_Interview = date_Of_Interview;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
